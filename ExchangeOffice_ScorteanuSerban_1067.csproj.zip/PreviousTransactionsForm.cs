﻿using ExchangeOffice_ScorteanuSerban.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace ExchangeOffice_ScorteanuSerban
{
    public partial class PreviousTransactionsForm : Form
    {
        public PreviousTransactionsForm()
        {
            InitializeComponent();
        }

        private void PreviousTransactionsForm_Load(object sender, EventArgs e)
        {
            transactionBindingSource.DataSource = MainForm.transactions;
        }


        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSerializeBinary_Click(object sender, EventArgs e)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            using (FileStream stream = File.Create("transaction.bin"))
            {
                formatter.Serialize(stream, MainForm.transactions);
            }
        }

        // how do I refresh when Deserealizing if I'm using DataBinding?
        private void btnDeserealizeBinary_Click(object sender, EventArgs e)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            using (FileStream stream = File.OpenRead("transaction.bin"))
            {
                MainForm.transactions = (BindingList<Transaction>)formatter.Deserialize(stream);
            }
        }

        private void btnSerializeXML_Click(object sender, EventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Transaction>));
            using (FileStream stream = File.Create("transactions.xml"))
            {
                serializer.Serialize(stream, MainForm.transactions);
            }
        }

        private void btnDeserializeXML_Click(object sender, EventArgs e)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Transaction>));
            using (FileStream stream = File.OpenRead("transaction.xml"))
            {
                MainForm.transactions = (BindingList<Transaction>)serializer.Deserialize(stream);
            }
        }

        private void btnSerializeJSON_Click(object sender, EventArgs e)
        {
            JsonSerializer serializer = new JsonSerializer();
            using(StreamWriter writer = File.CreateText("transactions.json"))
            {
                serializer.Serialize(writer, MainForm.transactions);
            }
        }

        private void btnDeserializeJSON_Click(object sender, EventArgs e)
        {
            JsonSerializer serializer = new JsonSerializer();
            using (StreamReader reader = File.OpenText("transactions.json"))
            {
                MainForm.transactions = (BindingList<Transaction>)serializer.Deserialize(reader, typeof(BindingList<Transaction>));
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "Export to CSV";
            // save as
            saveFileDialog.Filter = "CSV File| *.csv";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter writer = File.CreateText(saveFileDialog.FileName))
                {
                    writer.WriteLine("Initial Sum,Final Sum,From Coin,To Coin,Conversion Rate");
                    foreach (Transaction transaction in MainForm.transactions)
                    {
                        // to short date string so it won't get the time as well
                        // use " " to wrap the name so it can contain space between names
                        writer.WriteLine($"\"{transaction.InitialSum}\",\"{transaction.FinalSum}\"," +
                            $"\"{transaction.FromCoin}\",\"{transaction.ToCoin}\",\"{transaction.Rate}\"");
                    }
                }
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            //OpenFileDialog openFileDialog = new OpenFileDialog();
            //openFileDialog.Title = "Import from CSV";
            //openFileDialog.Filter = "CSV File| *.csv";
            //if (openFileDialog.ShowDialog() == DialogResult.OK)
            //{
            //    using (StreamReader reader = File.OpenText(openFileDialog.FileName))
            //    {
            //        reader.ReadLine();
            //        while (true)
            //        {
            //            string line = reader.ReadLine().ToString();
            //            Transaction transaction = new Transaction();
            //            transaction.InitialSum = Double.Parse(line.Split(',')[0]);
            //            transaction.FinalSum = Double.Parse(line.Split(',')[1]);
            //            transaction.FromCoin.Coin = line.Split(',')[2];
            //            transaction.ToCoin.Coin = line.Split(',')[3];
            //            string longRate = line.Substring(line.IndexOf(line.Split(',')[4]), line.Length);
            //            //  I WILL FINISH THIS!
            //            MainForm.transactions.Add(transaction);
            //            if (reader.Peek() == -1)
            //            {
            //                break;
            //            }                    
            //    }
            //}
        }
    }
}
