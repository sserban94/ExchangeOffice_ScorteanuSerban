﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExchangeOffice_ScorteanuSerban.Entities
{
    [Serializable]
    public class Transaction
    {
        public long Id { get; set; }
        private double initialSum;
        public double InitialSum
        {
            get { return initialSum; }
            set
            {
                if (value < 0)
                {
                    throw new InvalidSumException(value);
                }
                initialSum = value;
            }
        }
        public double FinalSum { get; set; }
        public Currency FromCoin { get; set; }
        public Currency ToCoin { get; set; }
        public ExchangeRate Rate { get; set; }

        public Transaction()
        {
            //InitialSum = 0;
            //FinalSum = 0;
            //FromCoin = new Currency();
            //ToCoin = new Currency();
            //Rate = null;
        }

        public Transaction(double initialSum, double finalSum, Currency fromCoin,
            Currency toCoin, ExchangeRate rate)
        {
            InitialSum = initialSum;
            FinalSum = finalSum;
            FromCoin = fromCoin;
            ToCoin = toCoin;
            Rate = rate;
        }

        public Transaction(long id, double initialSum, double finalSum, Currency fromCoin,
            Currency toCoin, ExchangeRate rate)
            :this(initialSum, finalSum, fromCoin,
            toCoin, rate)
        {
            Id = id;
        }
    }
}
