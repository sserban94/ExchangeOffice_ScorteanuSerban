﻿using ExchangeOffice_ScorteanuSerban.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//# Requirements

//DONE//1.Declare / implement the entities(classes)
//DONE//2.Create forms that allow users to input / update / delete data (at least for the three classes specified in the project topics)
//DONE//3.Add data validation(ErrorProvider control, Validating/Validated events, standard exceptions, custom exceptions)
//IMPLEMENTED IN MAIN FORM. DON'T WORK//4.Implement Alt Shortcuts
//DONE (IT REFRESHES ONLY WHEN CLOSING AND OPENING FORMS)//5. Add data serialization / deserialization
//DONE//6. Add the option to export a report as a txt file
//DONE(didn't use toolstrip(same as menustrip??)//7. Use all the following menu controls: MenuStrip, ToolStrip, StatusStrip, ContextMenuStrip

//NO//8.Draw a chart using the System.Drawing.Graphics class, in order to represent some statistics that are meaningful for your application. You should not use an existing chart control, like the one available in the ToolBox (the goal is to create such a control yourself). The control should be different from the ones available on http://github.com/liviucotfas (discussed during the course / during the labs). You can check the charts in Microsoft Excel for inspiration.
//NO//9.Offer the possibility to print a document (with PrintPreview)
//NO//10.Implement the drag & drop functionality

//IMPLEMENTED IN ONE FORM. DOESN'T FIND TABLE//11. Use a relational database in order to persist data (for at least two different entities / classes) in your app
//NO//12. Implement a UserControl in a separate project and use it in your app (so that it can be distributed to other developers). The UserControl should provide a useful functionality for your app (please don't copy&paste a clock usercontrol from the internet ;) )

//DONE//13. Data binding

// CONCLUSION - 1,2,3,5,6,13 - DONE
//              4, 11 - DON'T WORK
//              9, 10 - OPTIONAL. DIDN'T IMPLEMENT
//              8, 12 - MANDATORY. DIDN'T IMPLEMENT
// ALSO - THE EXCHANGE RATES FORM - tried to remove "Ron" from the list - no chance
//      - TRIED TO IMPORT ASWELL BUT I GAVE UP FOR TODAY

// 7/11 64% ?
//# Submission


namespace ExchangeOffice_ScorteanuSerban
{
    public partial class MainForm : Form
    {
        #region Attributes
        public static List<Currency> currencies;
        public static BindingList<Transaction> transactions;
        public static BindingList<ExchangeRate> exchangeRates;
        public static string connectionString = "Data source=transactionsDb.db";

        #endregion
        public MainForm()
        {
            InitializeComponent();

            currencies = new List<Currency>();
            transactions = new BindingList<Transaction>();
            exchangeRates = new BindingList<ExchangeRate>();
        }
        #region Methods
        private void LoadCurrencies()
        {
            currencies.Add(new Currency("Euro"));
            currencies.Add(new Currency("Dollar"));
            currencies.Add(new Currency("Ron"));
        }

        private void LoadExchangeRates()
        {
            // Euro-Dollar, Euro-Lei, Dollar-Lei
            
            exchangeRates.Add(new ExchangeRate("EuroRon", "Multiplication", 4.93, DateTime.Now));
            exchangeRates.Add(new ExchangeRate("RonEuro","Division", 4.93, DateTime.Now));
            exchangeRates.Add(new ExchangeRate("DollarRon", "Multiplication", 4.05, DateTime.Now));
            exchangeRates.Add(new ExchangeRate("RonDollar","Division", 4.05, DateTime.Now));
            exchangeRates.Add(new ExchangeRate("EuroDollar", "Multiplication", 1.22, DateTime.Now));            
            exchangeRates.Add(new ExchangeRate("DollarEuro", "Division", 1.22, DateTime.Now));            
        }

        #endregion

        #region Events
        private void btnMakeTransaction_Click(object sender, EventArgs e)
        {
            NewTransactionForm newTransactionForm = new NewTransactionForm();
            newTransactionForm.Show();
        }

        private void btnCheckPrevious_Click(object sender, EventArgs e)
        {
            PreviousTransactionsForm previousTransactionsForm = new PreviousTransactionsForm();
            previousTransactionsForm.Show();
        }

        private void btnCheckRates_Click(object sender, EventArgs e)
        {
            ExchangeRatesForm exchangeRatesForm = new ExchangeRatesForm();
            exchangeRatesForm.Show();
        }
        #endregion

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
            try
            {
                LoadCurrencies();
                LoadExchangeRates();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            // bug - e.control is false so this doesn't work :(
            if (e.Control == true && e.KeyCode.ToString() == "1")
            {
                btnMakeTransaction.PerformClick();
            }
            if (e.Control == true && e.KeyCode.ToString() == "2")
            {
                btnCheckPrevious.PerformClick();
            }
            if (e.Control == true && e.KeyCode.ToString() == "3")
            {
                btnCheckRates.PerformClick();
            }

        }
    }
}
